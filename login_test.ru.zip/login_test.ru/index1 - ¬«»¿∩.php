<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Увеличение и перемещение изображения</title>
    <style>
        .thumbnail {
            position: relative;
            display: inline-block;
        }

        .thumbnail:hover .popup {
            display: block;
        }

        .popup {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            border: 1px solid #ccc;
            padding: 10px;
            z-index: 1;
        }
    </style>
</head>
<body>
    <div class="thumbnail">
        <img src="\auth\captcha.png" alt="Изображение" width="300" height="200">
        <div class="popup">
            <?php
            $imagePath = 'Z:\home\login_test.ru\www\auth\captcha.png';
            $image = imagecreatefrompng($imagePath);
            $zoomFactor = 20;
            $imageWidth = imagesx($image) * $zoomFactor;
            $imageHeight = imagesy($image) * $zoomFactor;
            $zoomed = imagecreatetruecolor($imageWidth, $imageHeight);
			// Установите альфа-канал для сохранения прозрачности
			imagealphablending($zoomed, false);
			imagesavealpha($zoomed, true);
            imagecopyresampled($zoomed, $image, 0, 0, 0, 0, $imageWidth, $imageHeight, imagesx($image), imagesy($image));
            ob_start();
            imagepng($zoomed);
            $image_data = ob_get_contents();
            ob_end_clean();
            echo '<img id="zoomed-image" src="data:image/png;base64,' . base64_encode($image_data) . '" width="' . $imageWidth . '" height="' . $imageHeight . '">';
            imagedestroy($image);
            imagedestroy($zoomed);
            ?>
        </div>
    </div>

    <script>
        const popup = document.querySelector('.popup');
        const zoomedImg = document.getElementById('zoomed-image');

        // Добавляем обработчики событий для перемещения
        let isDragging = false;
        let offsetX, offsetY;

        popup.addEventListener('mousedown', (e) => {
            isDragging = true;
            offsetX = e.clientX - popup.getBoundingClientRect().left;
            offsetY = e.clientY - popup.getBoundingClientRect().top;
        });

        window.addEventListener('mousemove', (e) => {
            if (isDragging) {
                const newX = e.clientX - offsetX;
                const newY = e.clientY - offsetY;
                popup.style.left = newX + 'px';
                popup.style.top = newY + 'px';
            }
        });

        window.addEventListener('mouseup', () => {
            isDragging = false;
        });
    </script>
</body>
</html>