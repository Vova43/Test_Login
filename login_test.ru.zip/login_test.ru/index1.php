<!DOCTYPE html>
<html>
<head>
    <title>Просмотр изображения с зумом</title>
    <style>
        #image-container {
            text-align: center;
        }
        #zoomed-image {
            max-width: 100%;
            max-height: 100%;
            cursor: zoom-out;
        }
    </style>
</head>
<body>
    <div id="image-container">
        <img id="zoomed-image" src="\auth\captcha.png" alt="Изображение" onclick="zoomImage()">
    </div>

    <script>
        function zoomImage() {
            var img = document.getElementById('zoomed-image');
            if (img.style.cursor === 'zoom-in') {
                img.style.cursor = 'zoom-out';
                img.style.maxWidth = '100%';
                img.style.maxHeight = '100%';
            } else {
                img.style.cursor = 'zoom-in';
                img.style.maxWidth = 'none';
                img.style.maxHeight = 'none';
            }
        }
    </script>
</body>
</html>