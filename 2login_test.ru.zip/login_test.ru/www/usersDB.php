<?php

return array (
  0 => 
  array (
    'login' => '1',
    'password' => '2',
  ),
);
