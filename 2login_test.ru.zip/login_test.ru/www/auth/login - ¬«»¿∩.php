<?php
session_start();
if (isset($_SESSION['authenticated']) || $_SESSION['authenticated'] == true) {
	if (isset($_SESSION['username']) || $_SESSION['username'] == true) {
		header('Location: /index.php');
	}
}
if (!empty($_POST)) {
    require __DIR__ . '/auth.php';

    $login = isset($_POST['login']) ? $_POST['login'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
	
    if (checkAuth($login, $password)) {
        header('Location: /index.php');
    } else {
        $error = 'Ошибка авторизации.';
    }
}
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Форма авторизации</title>
		<style>
			.input[type=text], input[type=password], input[type=submit], input[type=button] {
				//background-color: #fffff;
				border: 1px solid #808080; /* Серая граница */
				//display: block; /* Элементы ввода находятся на новой строке */
			}
			.input[type=text], input[type=password], input[type=submit], input[type=button]:focus {
				//background-color: #5a5a5a;
				border: 1px solid #808080; /* Серая граница */
				outline: none;
				//display: block; /* Элементы ввода находятся на новой строке */
			}

			.form {
				border: 3px solid #000000; /* Цвет границы и ее толщина */
				padding: 20px; /* Отступ внутри формы */
				display: inline-block; /* Размер формы подстраивается под контент */
			}
		</style>
	</head>
	<body>
		<form class="form" method="post" action="login.php">
			<?php if (isset($error)): ?>
				<span style="color: red;">
					<?php echo $error; ?>
				</span>
				<br>
			<?php endif; ?>
			<label for="login" >Имя пользователя(login): </label><br>
			<input class="input" type="text" name="login" id="login"><br><br>
			<label for="password">Пароль(password): </label><br>
			<input class="input" type="password" name="password" id="password"><br><br>
			<input class="input" type="submit" value="Войти"> 
			<input class="input" type="button" value="Регистрация" style="float: right;" onclick="header('Location: /register.php')" >
		</form>
		<script>
			function redirectToRegister() {
				window.location.href = 'register.php';
			}
		</script>
	</body>
</html>