<?php

return array (
  0 => 
  array (
    'login' => 'f',
    'password' => 'f',
  ),
);
