<?php

function checkAuth($login, $password)
{
    $users = require dirname(__DIR__) . '/usersDB.php';
	
    foreach ($users as $user) {
        if ($user['login'] === $login
            && $user['password'] === $password
        ) {
            return true;
        }
    }

    return false;
}

function getUserLogin()
	{
	if (isset($_COOKIE['login'])) {
		$loginFromCookie = $_COOKIE['login'];
	} else {
		$loginFromCookie = '';
	}
	
	if (isset($_COOKIE['password'])) {
		$passwordFromCookie = $_COOKIE['password'];
	} else {
		$passwordFromCookie = '';
	}

    if (checkAuth($loginFromCookie, $passwordFromCookie)) {
        return $loginFromCookie;
    }

    return null;
}

function registerUser($login, $password)
{
    $users = require dirname(__DIR__) . '/usersDB.php';
	foreach ($users as $user) {
        if ($user['login'] === $login) {
            return false; // Логин уже занят
        }
    }
    $newUser = array(
        'login' => $login,
        'password' => $password,
    );
    $users[] = $newUser;

    $serializedUsers = var_export($users, true);
    file_put_contents(dirname(__DIR__) . '/usersDB.php', "<?php\n\nreturn $serializedUsers;\n"); 

    return true;
}
?>