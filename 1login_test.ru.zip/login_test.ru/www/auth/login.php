<?php
if (!empty($_POST)) {
    require __DIR__ . '/auth.php';

    $login = isset($_POST['login']) ? $_POST['login'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if (checkAuth($login, $password)) {
        setcookie('login', $login, 0, '/');
        setcookie('password', $password, 0, '/');
        header('Location: /index.php');
    } else {
        $error = 'Ошибка авторизации';
    }
}
?>
<html>
<head>
	<meta charset="UTF-8">
    <title>Форма авторизации</title>
	
	<style>
.input[type=text], input[type=password], input[type=submit] {
  //background-color: #fffff;
  border: 1px solid #808080; /* Серая граница */
}
.input[type=text], input[type=password], input[type=submit]:focus {
  //background-color: #5a5a5a;
  border: 1px solid #808080; /* Серая граница */
  outline: none;
}

.button {
    background-color: #c0c0c0; /* Серый фон */
    border: 1px solid #808080; /* Серая граница */
    color: #000; /* Черный текст */
    padding: 5px 10px; /* Внутренний отступ кнопки */
    font-family: Arial, sans-serif; /* Шрифт, аналогичный Windows 95 */
    cursor: pointer; /* Заменяет указатель мыши при наведении */
}

/* Эффект наведения (при наведении курсора) */
.button:hover {
    background-color: #f0f0f0; /* Светло-серый фон */
}

/* Эффект нажатия (при клике) */
.button:active {
    background-color: #808080; /* Серый фон */
    border: 1px inset #000; /* Вдавленная граница */
    color: #fff; /* Белый текст */
}

</style>
</head>
<body>

<?php if (isset($error)): ?>
<span style="color: red;">
    <?php echo $error; ?>
</span>
<?php endif; ?>

<form method="post" action="login.php">
    <label for="login">Имя пользователя(login): </label><input class="input" type="text" name="login" id="login">
    <br>
    <label for="password">Пароль(password): </label><input class="input" type="password" name="password" id="password">
    <br>
    <input type="submit" class="input" value="Войти">
</form>
</body>
</html>