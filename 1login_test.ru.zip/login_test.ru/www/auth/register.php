<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'];
    $password = $_POST['password'];
	require __DIR__ . '/auth.php';

    if (registerUser($login, $password)) {
        echo 'Регистрация успешно завершена. <a href="login.php">Войти</a>';
    } else {
        echo 'Пользователь с таким логином уже существует.';
    }
}
?>

<form method="post" action="register.php">
    <label for="login">Логин:</label>
    <input type="text" name="login" id="login" required><br>

    <label for="password">Пароль:</label>
    <input type="password" name="password" id="password" required><br>

    <input type="submit" value="Зарегистрироваться">
</form>