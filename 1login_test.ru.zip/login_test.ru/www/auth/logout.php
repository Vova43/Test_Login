<?php
// Очищаем куки аутентификации
setcookie('login', '', time() - 3600, '/');
setcookie('password', '', time() - 3600, '/');

// Перенаправляем пользователя на страницу входа
header('Location: /auth/login.php');
exit; // Завершаем выполнение скрипта
?>