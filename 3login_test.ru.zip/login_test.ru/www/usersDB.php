<?php

return array (
  0 => 
  array (
    'login' => '1',
    'password' => '2',
  ),
  1 => 
  array (
    'login' => '',
    'password' => '',
  ),
  2 => 
  array (
    'login' => false,
    'password' => '',
  ),
  3 => 
  array (
    'login' => 'акп',
    'password' => 'кпкп',
  ),
  4 => 
  array (
    'login' => 'sd',
    'password' => 'sdsd',
  ),
);
